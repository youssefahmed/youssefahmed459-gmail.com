# YoutubeEmbedApp
How To Embed YouTube Videos Into Your App In Xcode 10 (Swift 4.2)

Youtube Link.

[![swift Embed YouTube Videos ](https://img.youtube.com/vi/-syN8aFZz0w/0.jpg)](https://www.youtube.com/watch?v=-syN8aFZz0w)

https://www.youtube.com/watch?v=-syN8aFZz0w
